import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./RecentResponses.module.css";

const RecentResponses = () => {
  const navigate = useNavigate();

  const onProfileImageClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onEditProfileContainerClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onRecentlyPostedTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onGroupContainer1Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer2Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer3Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer4Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onPostButtonClick = useCallback(() => {
    navigate("/new-jobpage2");
  }, [navigate]);

  const onGroupContainer5Click = useCallback(() => {
    navigate("/all-responses");
  }, [navigate]);

  return (
    <div className={styles.recentResponses}>
      <div className={styles.navbar} />
      <div className={styles.recentResponsesChild} />
      <img
        className={styles.profileImageIcon}
        alt=""
        src="/profile-image1@2x.png"
        onClick={onProfileImageClick}
      />
      <div className={styles.profile}>
        <div className={styles.profile1} />
        <img
          className={styles.profileImageIcon1}
          alt=""
          src="/profile-image@2x.png"
        />
        <div className={styles.emmaPoole}>Emma Poole</div>
        <div
          className={styles.editprofile}
          onClick={onEditProfileContainerClick}
        >
          <div className={styles.editProfileRectangle} />
          <div className={styles.editProfile}>Edit Profile</div>
        </div>
      </div>
      <div className={styles.lefttaskbar}>
        <div className={styles.lefttaskbarChild} />
        <div className={styles.lefttaskbarItem} />
        <div
          className={styles.recentlyPosted}
          onClick={onRecentlyPostedTextClick}
        >
          Recently Posted
        </div>
        <div className={styles.recentResponses1}>Recent Responses</div>
      </div>
      <div className={styles.faqParent}>
        <div className={styles.faq}>FAQ</div>
        <div className={styles.home}>Home</div>
        <div className={styles.contactUs}>Contact Us</div>
        <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
      </div>
      <div className={styles.rectangleParent} onClick={onGroupContainer1Click}>
        <div className={styles.groupChild} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.mostRecentResponseContainer}>
          <span>Most Recent Response</span>
          <span className={styles.pm18012023}>: 6:05 p.m. 18/01//2023</span>
        </div>
        <div className={styles.viewAllResponses}>
          {" "}
          View All Responses for this Job
        </div>
        <img className={styles.teamwork2Icon} alt="" src="/teamwork-2@2x.png" />
      </div>
      <div className={styles.rectangleGroup} onClick={onGroupContainer2Click}>
        <div className={styles.groupChild} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.mostRecentResponseContainer}>
          <span>Most Recent Response</span>
          <span className={styles.pm18012023}>: 6:05 p.m. 18/01//2023</span>
        </div>
        <div className={styles.viewAllResponses}>
          {" "}
          View All Responses for this Job
        </div>
        <img className={styles.teamwork2Icon} alt="" src="/teamwork-2@2x.png" />
      </div>
      <div
        className={styles.rectangleContainer}
        onClick={onGroupContainer3Click}
      >
        <div className={styles.groupChild} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.mostRecentResponseContainer}>
          <span>Most Recent Response</span>
          <span className={styles.pm18012023}>: 6:05 p.m. 18/01//2023</span>
        </div>
        <div className={styles.viewAllResponses}>
          {" "}
          View All Responses for this Job
        </div>
        <img className={styles.teamwork2Icon} alt="" src="/teamwork-2@2x.png" />
      </div>
      <div className={styles.groupDiv} onClick={onGroupContainer4Click}>
        <div className={styles.groupChild} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.mostRecentResponseContainer}>
          <span>Most Recent Response</span>
          <span className={styles.pm18012023}>: 6:05 p.m. 18/01//2023</span>
        </div>
        <div className={styles.viewAllResponses}>
          {" "}
          View All Responses for this Job
        </div>
        <img className={styles.teamwork2Icon} alt="" src="/teamwork-2@2x.png" />
      </div>
      <div className={styles.searchbar}>
        <div className={styles.searchbarChild} />
        <img className={styles.searchbarItem} alt="" src="/ellipse-1.svg" />
        <img className={styles.search1Icon} alt="" src="/search-1@2x.png" />
      </div>
      <div className={styles.companyName}>Company Name</div>
      <div className={styles.logout} onClick={onLogoutTextClick}>
        Logout
      </div>
      <div className={styles.centerpiece}>
        <div className={styles.center} />
        <div className={styles.newVacanyStart}>
          New vacany? Start your hiring right now!
        </div>
        <div className={styles.newjobform}>
          <input className={styles.enterJobTags} />
          <input className={styles.enterJobDescription} />
          <input className={styles.enterJobDescription1} />
          <input className={styles.enterJobTitle} />
          <input className={styles.enterJobPoc} />
          <div className={styles.dropdownTags}>
            <div className={styles.dropdownTagsChild} />
            <img
              className={styles.dropdownTagsItem}
              alt=""
              src="/polygon-1.svg"
            />
          </div>
          <div className={styles.jobTags}>Job Tags</div>
          <div className={styles.jobDescription}>Job Description</div>
          <div className={styles.jobTitle4}>Job Title</div>
          <div className={styles.jobPoc}>Job POC</div>
          <b className={styles.getStartedBy}>
            Get started by filling out these basics details
          </b>
          <div className={styles.post}>
            <div className={styles.postbutton} onClick={onPostButtonClick} />
            <div className={styles.post1}>Post</div>
          </div>
          <div className={styles.cutomTags}>
            <div className={styles.rectangle} />
            <div className={styles.addCustomTags}>Add Custom Tags</div>
          </div>
        </div>
      </div>
      <div className={styles.rectangleParent1} onClick={onGroupContainer5Click}>
        <div className={styles.groupChild1} />
        <div className={styles.viewAllRecent}>View All Recent Responses</div>
      </div>
    </div>
  );
};

export default RecentResponses;
