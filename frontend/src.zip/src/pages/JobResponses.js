import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./JobResponses.module.css";

const JobResponses = () => {
  const navigate = useNavigate();

  const onProfileImageClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onGroupContainer3Click = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onAllJobsContainerClick = useCallback(() => {
    navigate("/all-jobs");
  }, [navigate]);

  return (
    <div className={styles.jobResponses}>
      <div className={styles.rectangleParent}>
        <div className={styles.groupChild} />
        <div className={styles.pending}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Pending</span>
          </span>
        </div>
        <div className={styles.filterSort}>{`Filter & Sort`}</div>
        <div className={styles.filter}> Filter :</div>
        <div className={styles.completed}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.completed1}>Completed</span>
          </span>
        </div>
        <div className={styles.status}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Status</span>
          </span>
        </div>
        <div className={styles.sort}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.sort1}>{`Sort : `}</span>
          </span>
        </div>
        <div className={styles.dateTime}>{`Date & Time`}</div>
        <div className={styles.previousHire}>Previous Hire</div>
        <div className={styles.vacancies}> Vacancies</div>
        <div className={styles.rectangleGroup}>
          <div className={styles.groupItem} />
          <div className={styles.apply}> Apply</div>
        </div>
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.groupChild3} />
        <div className={styles.groupChild4} />
      </div>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image1@2x.png"
          onClick={onProfileImageClick}
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home} onClick={onHomeTextClick}>
            Home
          </div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.jobResponsesChild} />
      <b className={styles.allResponses}>All Responses</b>
      <div className={styles.youHaveReceived}>
        You have received a total of 7 responses for this job
      </div>
      <div
        className={styles.rectangleContainer}
        onClick={onGroupContainer3Click}
      >
        <div className={styles.groupChild5} />
        <img className={styles.teamwork3Icon} alt="" src="/teamwork-3@2x.png" />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTags}>Job Tags</div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <div className={styles.groupChild6} />
        <div className={styles.groupChild7} />
        <div className={styles.groupChild8} />
        <div className={styles.groupChild9} />
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag4}>Job Tag #4</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
      </div>
      <div className={styles.alljobs} onClick={onAllJobsContainerClick}>
        <div className={styles.alljobsChild} />
        <div className={styles.allJobs}>All Jobs</div>
      </div>
      <div className={styles.jobResponsesItem} />
      <div className={styles.jobResponsesInner} />
      <div className={styles.jobResponsesChild1} />
      <div className={styles.jobResponsesChild2} />
      <div className={styles.jobResponsesChild3} />
      <div className={styles.jobResponsesChild4} />
      <div className={styles.jobResponsesChild5} />
      <div className={styles.jobResponsesChild6} />
      <div className={styles.name}>Name</div>
      <div className={styles.ramu}>Ramu</div>
      <div className={styles.ramu1}>Ramu</div>
      <div className={styles.ramu2}>Ramu</div>
      <div className={styles.ramu3}>Ramu</div>
      <div className={styles.shambhu}>Shambhu</div>
      <div className={styles.shambhu1}>Shambhu</div>
      <div className={styles.shambhu2}>Shambhu</div>
      <div className={styles.date}>Date</div>
      <div className={styles.pm18022023}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220231}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220232}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220233}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220234}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220235}>6:05 PM 18/02/2023</div>
      <div className={styles.pm180220236}>6:05 PM 18/02/2023</div>
      <div className={styles.phoneNo}>Phone No</div>
      <div className={styles.div}>1234567891</div>
      <div className={styles.div1}>1234567891</div>
      <div className={styles.div2}>1234567891</div>
      <div className={styles.div3}>1234567891</div>
      <div className={styles.div4}>1234567891</div>
      <div className={styles.div5}>1234567891</div>
      <div className={styles.div6}>1234567891</div>
      <div className={styles.status2}>Status</div>
      <div className={styles.completed2}>Completed</div>
      <div className={styles.completed3}>Completed</div>
      <div className={styles.pending2}>Pending</div>
      <div className={styles.pending3}>Pending</div>
      <div className={styles.pending4}>Pending</div>
      <div className={styles.completed4}>Completed</div>
      <div className={styles.completed5}>Completed</div>
      <div className={styles.previousHires}>Previous Hires</div>
      <div className={styles.div7}>4</div>
      <div className={styles.div8}>4</div>
      <div className={styles.div9}>4</div>
      <div className={styles.div10}>4</div>
      <div className={styles.div11}>4</div>
      <div className={styles.div12}>4</div>
      <div className={styles.div13}>4</div>
    </div>
  );
};

export default JobResponses;
