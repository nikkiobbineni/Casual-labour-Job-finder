import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AllResponses.module.css";

const AllResponses = () => {
  const navigate = useNavigate();

  const onProfileImageClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onGroupContainer1Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer2Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer3Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  const onGroupContainer4Click = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  return (
    <div className={styles.allResponses}>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image1@2x.png"
          onClick={onProfileImageClick}
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home} onClick={onHomeTextClick}>
            Home
          </div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.rectangleParent} onClick={onGroupContainer1Click}>
        <div className={styles.groupChild} />
        <div className={styles.groupItem} />
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
        <div className={styles.viewAllResponses}>View All Responses</div>
      </div>
      <div className={styles.rectangleGroup} onClick={onGroupContainer2Click}>
        <div className={styles.groupChild} />
        <div className={styles.groupItem} />
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
        <div className={styles.viewAllResponses}>View All Responses</div>
      </div>
      <div
        className={styles.rectangleContainer}
        onClick={onGroupContainer3Click}
      >
        <div className={styles.groupChild} />
        <div className={styles.groupItem} />
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
        <div className={styles.viewAllResponses}>View All Responses</div>
      </div>
      <div className={styles.groupDiv} onClick={onGroupContainer4Click}>
        <div className={styles.groupChild} />
        <div className={styles.groupItem} />
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
        <div className={styles.viewAllResponses}>View All Responses</div>
      </div>
      <div className={styles.allResponsesChild} />
      <img className={styles.allResponsesItem} alt="" src="/rectangle-30.svg" />
      <div className={styles.text}>{`   `}</div>
      <div className={styles.text1}>{`   `}</div>
      <div className={styles.rectangleParent1}>
        <div className={styles.groupChild13} />
        <div className={styles.groupChild14} />
        <div className={styles.groupChild15} />
        <div className={styles.groupChild16} />
        <div className={styles.groupChild17} />
        <div className={styles.groupChild18} />
        <div className={styles.groupChild19} />
        <div className={styles.groupChild20} />
        <div className={styles.groupChild21} />
        <div className={styles.pending}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Pending</span>
          </span>
        </div>
        <div className={styles.filterSort}>{`Filter & Sort`}</div>
        <div className={styles.filter}> Filter :</div>
        <div className={styles.completed}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.completed1}>Completed</span>
          </span>
        </div>
        <div className={styles.groupChild22} />
        <div className={styles.category}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Category</span>
          </span>
        </div>
        <div className={styles.sort}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.sort1}>{`Sort : `}</span>
          </span>
        </div>
        <div className={styles.date}> Date</div>
        <div className={styles.responses}> Responses</div>
        <div className={styles.vacancies}> Vacancies</div>
        <div className={styles.apply}> Apply</div>
        <div className={styles.groupChild23} />
        <div className={styles.groupChild24} />
        <div className={styles.groupChild25} />
        <div className={styles.groupChild26} />
        <div className={styles.groupChild27} />
        <div className={styles.groupChild28} />
      </div>
      <div className={styles.youHaveReceivedContainer}>
        <span className={styles.pendingTxt}>
          <p className={styles.youHaveReceived}>
            You have received the following responses for a job:
          </p>
          <p className={styles.clickOnA}>
            Click on a job to know more and edit
          </p>
        </span>
      </div>
    </div>
  );
};

export default AllResponses;
