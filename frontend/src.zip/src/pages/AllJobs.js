import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AllJobs.module.css";

const AllJobs = () => {
  const navigate = useNavigate();

  const onProfileImageClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onJobContainerClick = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onJob2ContainerClick = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onJob3ContainerClick = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onJob4ContainerClick = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  return (
    <div className={styles.allJobs}>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image1@2x.png"
          onClick={onProfileImageClick}
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home} onClick={onHomeTextClick}>
            Home
          </div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.job} onClick={onJobContainerClick}>
        <div className={styles.jobChild} />
        <div className={styles.jobItem} />
        <div className={styles.jobInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
      </div>
      <div className={styles.job2} onClick={onJob2ContainerClick}>
        <div className={styles.jobChild} />
        <div className={styles.jobItem} />
        <div className={styles.jobInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
      </div>
      <div className={styles.job3} onClick={onJob3ContainerClick}>
        <div className={styles.jobChild} />
        <div className={styles.jobItem} />
        <div className={styles.jobInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
      </div>
      <div className={styles.job4} onClick={onJob4ContainerClick}>
        <div className={styles.jobChild} />
        <div className={styles.jobItem} />
        <div className={styles.jobInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img
          className={styles.teamwork1Icon}
          alt=""
          src="/teamwork-11@2x.png"
        />
      </div>
      <div className={styles.allJobsChild} />
      <img className={styles.allJobsItem} alt="" src="/rectangle-30.svg" />
      <div className={styles.text}>{`   `}</div>
      <div className={styles.text1}>{`   `}</div>
      <div className={styles.rectangleParent}>
        <div className={styles.groupChild} />
        <div className={styles.pending}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Pending</span>
          </span>
        </div>
        <div className={styles.filterSort}>{`Filter & Sort`}</div>
        <div className={styles.filter}> Filter :</div>
        <div className={styles.completed}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.completed1}>Completed</span>
          </span>
        </div>
        <div className={styles.groupItem} />
        <div className={styles.category}>
          <span className={styles.pendingTxt}>
            <span className={styles.span}>{`  `}</span>
            <span className={styles.pending1}>Category</span>
          </span>
        </div>
        <div className={styles.sort}>
          <span className={styles.pendingTxt}>
            <span>{`  `}</span>
            <span className={styles.sort1}>{`Sort : `}</span>
          </span>
        </div>
        <div className={styles.date}> Date</div>
        <div className={styles.responses}> Responses</div>
        <div className={styles.vacancies}> Vacancies</div>
        <div className={styles.apply}> Apply</div>
        <div className={styles.groupInner} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.groupChild3} />
        <div className={styles.groupChild4} />
        <div className={styles.groupChild5} />
      </div>
      <img className={styles.edit1Icon} alt="" src="/edit-1@2x.png" />
      <img className={styles.edit2Icon} alt="" src="/edit-1@2x.png" />
      <img className={styles.edit3Icon} alt="" src="/edit-1@2x.png" />
      <img className={styles.edit4Icon} alt="" src="/edit-1@2x.png" />
      <div className={styles.youHavePostedContainer}>
        <span className={styles.pendingTxt}>
          <p className={styles.youHavePosted}>
            You have posted the following jobs:
          </p>
          <p className={styles.clickOnA}>
            Click on a job to know more and edit
          </p>
        </span>
      </div>
    </div>
  );
};

export default AllJobs;
