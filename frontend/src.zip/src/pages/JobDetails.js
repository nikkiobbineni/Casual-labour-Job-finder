import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./JobDetails.module.css";

const JobDetails = () => {
  const navigate = useNavigate();

  const onProfileImageClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onViewAllResponsesContainerClick = useCallback(() => {
    navigate("/job-responses");
  }, [navigate]);

  return (
    <div className={styles.jobDetails}>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image1@2x.png"
          onClick={onProfileImageClick}
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home} onClick={onHomeTextClick}>
            Home
          </div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.text}>{`   `}</div>
      <div className={styles.text1}>{`   `}</div>
      <div className={styles.jobDetailsChild} />
      <div className={styles.wages}>Wages</div>
      <div className={styles.jobDetailsItem} />
      <div className={styles.jobTags}>Job Tags:</div>
      <div className={styles.jobTitle}>Job Title</div>
      <div className={styles.jobDetailsInner} />
      <div className={styles.rectangleDiv} />
      <div className={styles.jobDetailsChild1} />
      <div className={styles.jobDetailsChild2} />
      <div className={styles.jobDetailsChild3} />
      <div className={styles.jobTag1}>Job Tag#1</div>
      <div className={styles.jobTag2}>Job Tag#2</div>
      <div className={styles.jobTag3}>Job Tag#3</div>
      <div className={styles.rectangleParent}>
        <div className={styles.groupChild} />
        <div className={styles.groupItem} />
        <div className={styles.groupInner} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.groupChild3} />
        <div className={styles.groupChild4} />
        <div className={styles.groupChild5} />
        <div className={styles.groupChild6} />
        <div className={styles.groupChild7} />
        <div className={styles.groupChild8} />
        <div className={styles.groupChild9} />
        <div className={styles.startDate}>Start Date</div>
        <div className={styles.endDate}>End Date</div>
        <div className={styles.duration}>Duration</div>
        <div className={styles.emailId}>Email ID</div>
        <div className={styles.vacancies}>Vacancies</div>
        <div className={styles.phoneNo}>Phone No</div>
        <div className={styles.location}>Location</div>
        <div className={styles.poc}>POC</div>
        <div className={styles.area}>Area</div>
        <div className={styles.div}>05/03/2023</div>
        <div className={styles.div1}>18/03/2023</div>
        <div className={styles.hours}>50 hours</div>
        <div className={styles.xyzgmailcom}>xyz.@gmail.com</div>
        <div className={styles.div2}>50</div>
        <div className={styles.div3}>1234567891</div>
        <div className={styles.bakulNivasIiit}>Bakul Nivas, IIIT Hyderabad</div>
        <div className={styles.mrXyz}>Mr. XYZ</div>
        <div className={styles.gachibowli}>Gachibowli</div>
        <div className={styles.responsesReceived}>Responses received</div>
        <img className={styles.ellipseIcon} alt="" src="/ellipse-5.svg" />
        <div className={styles.div4}>7</div>
        <div className={styles.delete}>Delete</div>
        <div className={styles.edit}>Edit</div>
      </div>
      <img className={styles.icon} alt="" src="/937107-1@2x.png" />
      <img className={styles.teamwork4Icon} alt="" src="/teamwork-4@2x.png" />
      <div className={styles.descriptionLongEstablished}>
        Description :long established fact that a reader will be distracted by
        the readable content of a page when looking at its layout.
      </div>
      <div className={styles.allresponses}>
        <div className={styles.allresponsesChild} />
        <div className={styles.allresponsesItem} />
        <div className={styles.allresponsesInner} />
        <div className={styles.allresponsesChild1} />
        <div className={styles.allresponsesChild2} />
        <div className={styles.allresponsesChild3} />
        <div className={styles.allresponsesChild4} />
        <div className={styles.allresponsesChild5} />
        <div className={styles.allresponsesChild6} />
        <div className={styles.allresponsesChild7} />
        <div className={styles.ramu9876543210}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432101}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432102}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432103}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432104}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432105}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432106}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432107}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.ramu98765432108}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span className={styles.ramu}>Ramu 9876543210</span>
          </span>
        </div>
        <div className={styles.allresponsesChild8} />
        <div className={styles.namePhoneNumberContainer}>
          <span className={styles.ramu9876543210TxtContainer}>
            <span>{`     `}</span>
            <span
              className={styles.name}
            >{`Name                     Phone Number    `}</span>
          </span>
        </div>
        <div className={styles.responsesReceived1}>Responses Received</div>
      </div>
      <div
        className={styles.viewAllResponses}
        onClick={onViewAllResponsesContainerClick}
      >
        <div className={styles.viewAllResponsesChild} />
        <div className={styles.viewAllResponses1}>
          View All Responses for this Job
        </div>
      </div>
      <div className={styles.to700}>500 to 700</div>
      <div className={styles.perDay}>per day</div>
    </div>
  );
};

export default JobDetails;
