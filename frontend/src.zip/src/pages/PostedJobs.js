import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./PostedJobs.module.css";

const PostedJobs = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [poc, setPOC] = useState("");
  const [description, setDescription] = useState("");
  const [phonenumber, setPhonenumber] = useState("-1");
  const [wages, setWages] = useState("-1");
  const [startdate, setStartdate] = useState("-1");
  const [enddate, setEnddate] = useState("-1");
  const [location, setLocation] = useState("-1");
  const [area, setArea] = useState("-1");
  const [tags, setTags] = useState("-1");
  const [vacancies, setVacancies] = useState("-1");
  const [email, setEmail] = useState("-1");
  const username = localStorage.getItem('username');
  // const [username, setUsername] = useState("");
  const onEditProfileContainerClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onRecentResponsesTextClick = useCallback(() => {
    navigate("/recent-responses");
  }, [navigate]);

  const onProfileImage1Click = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onGroupContainer2Click = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onGroupContainer3Click = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);

  const onGroupContainer4Click = useCallback(() => {
    navigate("/job-details");
  }, [navigate]);
  // setUsername("local.storage('username')")
  function onPostContainerClick() {
    console.log("shxhjsd")
    const fetchdata = async () => {
      const response = await fetch('http://localhost:4000/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
          mutation($input: JobsInput!) {
            createJobPartOne(input: $input) {
              id
              title
              poc
              description
              phonenumber
              email
              wages
              vacancies
              startdate
              enddate
              area
              location
              tags
              username
            }
          }
        `,
          variables: {
            input: {
              title: title,
              poc: poc,
              description: description,
              tags: tags,
              username: username,
              phonenumber: phonenumber,
              email: email,
              wages: wages,
              vacancies: vacancies,
              startdate: startdate,
              enddate: enddate,
              area: area,
              location: location
            }
          }
        })
      });
      const result = await response.json();
      console.log(result)
      if (!result.errors) {
        const jobId = result.data.createJobPartOne.id; // Define jobId here
        console.log(jobId); // Check the value of jobId
        navigate(`/new-jobpage2/${jobId}`); // Use jobId here
        console.log
      }
      else
      {
        console.log("ejxBWD")
      }
    }
    fetchdata();

  }
  const onViewAllJobsContainerClick = useCallback(() => {
    navigate("/all-jobs");
  }, [navigate]);

  return (
    <div className={styles.postedJobs}>
      <div className={styles.postedJobsChild} />
      <div className={styles.profile}>
        <div className={styles.profile1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image@2x.png"
        />
        <div className={styles.emmaPoole}>Emma Poole</div>
        <div
          className={styles.editprofile}
          onClick={onEditProfileContainerClick}
        >
          <div className={styles.editProfileRectangle} />
          <div className={styles.editProfile}>Edit Profile</div>
        </div>
      </div>
      <div className={styles.lefttaskbar}>
        <div className={styles.rectangleParent}>
          <div className={styles.groupChild} />
          <div className={styles.groupItem} />
          <div className={styles.recentlyPosted}>Recently Posted</div>
          <div
            className={styles.recentResponses}
            onClick={onRecentResponsesTextClick}
          >
            Recent Responses
          </div>
        </div>
      </div>
      <div className={styles.searchbar}>
        <div className={styles.searchbarChild} />
        <img className={styles.searchbarItem} alt="" src="/ellipse-1.svg" />
        <img className={styles.search1Icon} alt="" src="/search-1@2x.png" />
      </div>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon1}
          alt=""
          src="/profile-image1@2x.png"
          onClick={onProfileImage1Click}
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home}>Home</div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.rectangleGroup} onClick={onGroupContainer2Click}>
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img className={styles.teamwork1Icon} alt="" src="/teamwork-1@2x.png" />
      </div>
      <div
        className={styles.rectangleContainer}
        onClick={onGroupContainer3Click}
      >
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img className={styles.teamwork1Icon} alt="" src="/teamwork-1@2x.png" />
      </div>
      <div className={styles.groupDiv} onClick={onGroupContainer4Click}>
        <div className={styles.groupInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.groupChild1} />
        <div className={styles.groupChild2} />
        <div className={styles.jobTitle}>Job Title</div>
        <div className={styles.jobTag1}>Job Tag #1</div>
        <div className={styles.jobTag2}>Job Tag #2</div>
        <div className={styles.jobTag3}>Job Tag #3</div>
        <div className={styles.responses7Container}>
          <b>Responses</b>
          <span> : 7</span>
        </div>
        <div className={styles.duration50Container}>
          <b>{`Duration `}</b>
          <span>: 50 hours</span>
        </div>
        <div className={styles.vacancies150Container}>
          <b>{`Vacancies `}</b>
          <span>: 150</span>
        </div>
        <div className={styles.descriptionLongEstablished}>
          Description :long established fact that a reader will be distracted by
          the readable content of a page when looking at its layout.
        </div>
        <img className={styles.teamwork1Icon} alt="" src="/teamwork-1@2x.png" />
      </div>
      <div className={styles.centerpiece}>
        <div className={styles.center} />
        <div className={styles.newVacanyStart}>
          New vacany? Start your hiring right now!
        </div>
        <div className={styles.newjobform}>
          <input className={styles.enterEmailId} />
          <input className={styles.enterUsername}
            type="text"
            value={description}
            onChange={(e) => { setDescription(e.target.value) }} />
          <input className={styles.enterUsername1} />
          <input className={styles.enterFirstName}
            type="text"
            value={title}
            onChange={(e) => { setTitle(e.target.value) }} />
          <input className={styles.enterLastName}
            type="text"
            value={poc}
            onChange={(e) => { setPOC(e.target.value) }} />
          <div className={styles.jobTags}>Job Tags</div>
          <div className={styles.jobDescription}>Job Description</div>
          <div className={styles.jobTitle3}>Job Title</div>
          <div className={styles.jobPoc}>Job POC</div>
          <b className={styles.getStartedBy}>
            Get started by filling out these basics details
          </b>
          <div className={styles.post} onClick={onPostContainerClick}>
            <div className={styles.postbutton} />
            <div className={styles.post1}>Post</div>
          </div>
          <div className={styles.cutomTags}>
            <div className={styles.enterPassword} />
            <div className={styles.addCustomTags}>Add Custom Tags</div>
          </div>
        </div>
      </div>
      <div className={styles.dropdownTags}>
        <div className={styles.dropdownTagsChild} />
        <img className={styles.dropdownTagsItem} alt="" src="/polygon-1.svg" />
      </div>
      <div className={styles.viewalljobs} onClick={onViewAllJobsContainerClick}>
        <div className={styles.viewalljobsChild} />
        <div className={styles.viewAllPosted}>View All Posted Jobs</div>
      </div>
    </div>
  );
};

export default PostedJobs;
