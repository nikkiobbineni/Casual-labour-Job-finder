import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Profile.module.css";

const Profile = () => {
  const navigate = useNavigate();

  const onHomeTextClick = useCallback(() => {
    navigate("/posted-jobs");
  }, [navigate]);

  const onLogoutTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className={styles.profile}>
      <div className={styles.navbar}>
        <div className={styles.navbar1} />
        <img
          className={styles.profileImageIcon}
          alt=""
          src="/profile-image1@2x.png"
        />
        <div className={styles.faqParent}>
          <div className={styles.faq}>FAQ</div>
          <div className={styles.home} onClick={onHomeTextClick}>
            Home
          </div>
          <div className={styles.contactUs}>Contact Us</div>
          <div className={styles.jobsResponses}>{`Jobs & Responses`}</div>
        </div>
        <div className={styles.companyName}>Company Name</div>
        <div className={styles.logout} onClick={onLogoutTextClick}>
          Logout
        </div>
      </div>
      <div className={styles.profile1}>
        <div className={styles.profileChild} />
        <img className={styles.profileItem} alt="" src="/ellipse-2.svg" />
        <img className={styles.profileInner} alt="" src="/ellipse-2.svg" />
        <img className={styles.ellipseIcon} alt="" src="/ellipse-2.svg" />
        <div className={styles.div}>18</div>
        <div className={styles.div1}>267</div>
        <div className={styles.div2}>159</div>
        <img className={styles.icon} alt="" src="/160352-1@2x.png" />
        <img
          className={styles.profileImageIcon1}
          alt=""
          src="/profile-image2@2x.png"
        />
        <b className={styles.emmaPoole}>Emma Poole</b>
        <div className={styles.emmapoole}>@emmapoole</div>
        <div className={styles.totalJobsPosted}>Total Jobs Posted</div>
        <div className={styles.responsesReceived}>Responses Received</div>
        <div className={styles.totalPeopleHired}>Total People Hired</div>
      </div>
      <div className={styles.editprofile}>
        <div className={styles.editprofileChild} />
        <div className={styles.username} />
        <div className={styles.firstname} />
        <div className={styles.lastname} />
        <div className={styles.emailid} />
        <div className={styles.password} />
        <b className={styles.username1}>Username</b>
        <b className={styles.name}>Name</b>
        <div className={styles.emmapoole1}>@emmapoole</div>
        <div className={styles.emma}>Emma</div>
        <div className={styles.poole}>Poole</div>
        <div className={styles.emmapoolegmailcom}>emmapoole@gmail.com</div>
        <div className={styles.div3}>**************</div>
        <b className={styles.emailId}>Email ID</b>
        <b className={styles.password1}>Password</b>
        <div className={styles.edit}>
          <div className={styles.editChild} />
          <div className={styles.edit1}>Edit</div>
        </div>
        <div className={styles.delete}>
          <div className={styles.deleteChild} />
          <div className={styles.delete1}>Delete</div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
